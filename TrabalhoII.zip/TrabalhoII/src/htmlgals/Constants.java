package htmlgals;

public interface Constants extends ScannerConstants, ParserConstants
{
    int EPSILON  = 0;
    int DOLLAR   = 1;

    int t_INICIO = 2;
    int t_FIM = 3;
    int t_TEXTO = 4;
    int t_TITULO = 5;
    int t_IMAGEM = 6;
    int t_LINK = 7;
    int t_BOTAO = 8;
    int t_LABEL = 9;

}
