package htmlgals;

import compilador.Compilador;

public class Semantico implements Constants {

    public void executeAction(int action, Token token) throws SemanticError {
        String a, b;
        
        switch (action) {
            case 1:
                Compilador.pilha.push("<!DOCTYPE html>");
                Compilador.pilha.push("<html>");
                System.out.println("aqui no inicio");
                break;
            case 2:
                Compilador.pilha.push("/<html>");
                System.out.println("aqui no final");
                
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:

                break;
            case 6:
                break;
            case 7:
                Compilador.pilha.push("<body>");
                break;
            case 8:
                Compilador.pilha.pop();
                Compilador.pilha.pop();
                break;

            default:
                System.out.println("nada");
                break;

        }
    }
}
