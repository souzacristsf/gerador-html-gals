package htmlgals;

import compilador.Compilador;

public class Semantico implements Constants {

    public void executeAction(int action, Token token) throws SemanticError {
        StringBuilder ajudador = new StringBuilder();
        
        
        switch (action) {
            case 1:
                Compilador.pilha.push("<!DOCTYPE html>");
                Compilador.pilha.push("<html>");
                
                break;
            case 2:
                Compilador.pilha.push("<body>");
                Compilador.pilha.push("/<html>");
                
                
                
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:

                break;
            case 6:
                break;
            case 7:
                Compilador.pilha.push("<body>");
                break;
            case 8:
                ajudador.append(Compilador.pilha.pop()).append("\n");    
                ajudador.append(Compilador.pilha.pop()).append("\n");
                System.out.println(ajudador.toString());
                Compilador.pilha.push(ajudador.toString());
                break;

            default:
                
                break;

        }
    }
}
